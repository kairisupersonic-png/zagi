const { ethers } = require("ethers");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

// ---------------------------------------------------------------------------
// zayro constants (reverse-engineered from the official frontend)
// ---------------------------------------------------------------------------
const CHAIN_ID = 91342; // GIWA Sepolia
const RPC = process.env.ZAYRO_RPC || "https://sepolia-rpc.giwa.io";
const API = process.env.ZAYRO_API || "https://zayro.trade/api-giwa";

const EXCHANGE = "0xdc803967753cC6A01F9B2bcFc116047189C4a020";
const SESSION_KEYS = "0x14D6CE4dE7cC45A3aAEd406a66846E43FeD4b7b3";
const USDC = "0xaCbBC011dAb9515a46dc61401C147006b43C34Bf";
const FEE_ADDRESS = "0x0000000000000000000000000000000000000000";
const SESSION_DAYS = 29;
const USDC_DEC = 6;        // margin pakai 6 desimal
const PRICE_DEC = 8;       // harga relayer 8 desimal
const MIN_MARGIN = 1;      // USDC
const LIQ_BUFFER = 0.00048; // 4.8 bps
const MAX_LEVERAGE = Number(process.env.MAX_LEVERAGE || 50); // batas leverage bot (default 50x)

const OPEN_DOMAIN = { name: "Zayro Exchange", version: "1", chainId: CHAIN_ID, verifyingContract: EXCHANGE };
const OPEN_TYPES = {
  OpenIntent: [
    { name: "user", type: "address" },
    { name: "instrumentId", type: "uint32" },
    { name: "isLong", type: "bool" },
    { name: "fromQueued", type: "bool" },
    { name: "leverage", type: "uint32" },
    { name: "margin", type: "uint128" },
    { name: "limitPrice", type: "uint256" },
    { name: "deadline", type: "uint64" },
    { name: "nonce", type: "uint256" },
  ],
};
const CLOSE_TYPES = {
  CloseIntent: [
    { name: "user", type: "address" },
    { name: "positionId", type: "uint256" },
    { name: "deadline", type: "uint64" },
    { name: "nonce", type: "uint256" },
  ],
};
const REG_DOMAIN = { name: "Zayro SessionKeyManager", version: "1", chainId: CHAIN_ID, verifyingContract: SESSION_KEYS };
const REG_TYPES = {
  RegisterSessionKey: [
    { name: "user", type: "address" },
    { name: "sessionKey", type: "address" },
    { name: "feeAddress", type: "address" },
    { name: "expiry", type: "uint64" },
    { name: "nonce", type: "uint256" },
  ],
};

const SESSION_KEYS_ABI = [
  "function nonces(address) view returns (uint256)",
  "function isValidSessionKey(address,address) view returns (bool)",
];

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
const randNonce = () => BigInt("0x" + crypto.randomBytes(32).toString("hex"));
const deadline = () => BigInt(Math.floor(Date.now() / 1000) + 300);
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
const fmtUsdc = (raw) => (Number(BigInt(raw ?? 0)) / 1e6).toFixed(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(path_, body) {
  const res = await fetch(API + path_, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = {};
  try { data = await res.json(); } catch {}
  if (!res.ok) {
    const reason = String(data.reason ?? data.error ?? `relayer HTTP ${res.status}`);
    const err = new Error(reason);
    err.data = data;
    throw err;
  }
  return data;
}

// ---------------------------------------------------------------------------
// ZayroBot — 1 akun, multi market, multi posisi, long/short bebas
// ---------------------------------------------------------------------------
class ZayroBot {
  constructor(userPk, sessionPk) {
    this.provider = new ethers.JsonRpcProvider(RPC, { chainId: CHAIN_ID, name: "GIWA Sepolia" });
    this.user = new ethers.Wallet(userPk, this.provider);
    this.session = sessionPk ? new ethers.Wallet(sessionPk) : null;
    this.markets = new Map();   // coin -> instrumentId (BigInt)
    this.coins = new Map();     // instrumentId(BigInt) -> coin
    this.maxLev = new Map();    // coin -> max leverage
  }

  // ---- info ---------------------------------------------------------------
  async health() {
    const h = await api("/health");
    for (const m of h.markets ?? []) {
      if (m.retired) continue;
      this.markets.set(m.coin, BigInt(m.instrumentId));
      this.coins.set(BigInt(m.instrumentId), m.coin);
      this.maxLev.set(m.coin, m.maxLeverage != null ? Number(m.maxLeverage) : (m.coin === "ZRO" ? 100 : 1000));
    }
    return h;
  }

  midPrice(h, coin) {
    const p = h.prices?.[coin];
    if (!p || !p.bid || !p.ask) return null;
    return Number(BigInt(p.bid) + BigInt(p.ask)) / 2 / 1e8;
  }

  async account() {
    return api(`/account/${this.user.address}`);
  }

  // ---- session key ----------------------------------------------------------
  // Trade ditandatangani session key (burner), bukan wallet utama — sama seperti website.
  // Bot bikin sendiri dan daftarkan ke relayer via tanda tangan wallet utama.
  async ensureSessionKey() {
    await this.health();
    const sk = new ethers.Contract(SESSION_KEYS, SESSION_KEYS_ABI, this.provider);

    const tryExisting = async () => {
      if (!this.session) return false;
      try {
        return await sk.isValidSessionKey(this.user.address, this.session.address);
      } catch { return false; }
    };

    if (!this.session) {
      const walletFile = path.join(__dirname, `session-key-${this.user.address.toLowerCase()}.json`);
      if (fs.existsSync(walletFile)) {
        const j = JSON.parse(fs.readFileSync(walletFile, "utf8"));
        if (j.user && j.user.toLowerCase() === this.user.address.toLowerCase()) {
          this.session = new ethers.Wallet(j.pk);
        }
      }
    }
    if (await tryExisting()) {
      log("Session key aktif:", this.session.address);
      return this.session;
    }

    log("Mendaftarkan session key baru...");
    if (!this.session) this.session = ethers.Wallet.createRandom();
    const expiry = BigInt(Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400);
    const nonce = await sk.nonces(this.user.address);
    const signature = await this.user.signTypedData(REG_DOMAIN, REG_TYPES, {
      user: this.user.address,
      sessionKey: this.session.address,
      feeAddress: FEE_ADDRESS,
      expiry,
      nonce,
    });
    const r = await api("/session-key", {
      user: this.user.address,
      sessionKey: this.session.address,
      feeAddress: FEE_ADDRESS,
      expiry: expiry.toString(),
      signature,
    });
    log("Session key terdaftar:", this.session.address, "tx:", r.txHash);
    fs.writeFileSync(path.join(__dirname, `session-key-${this.user.address.toLowerCase()}.json`),
      JSON.stringify({ user: this.user.address, address: this.session.address, pk: this.session.privateKey }, null, 2));
    return this.session;
  }

  // ---- trading --------------------------------------------------------------
  // margin: USDC (>=1), leverage: number. Contoh: open('BTC', true, 2, 50)
  async open(coin, isLong, margin, leverage) {
    if (!this.session) throw new Error("Session key belum siap — jalankan `node cli.js setup` dulu");
    await this.health();
    const coinU = coin.toUpperCase();
    const instrumentId = this.markets.get(coinU);
    if (instrumentId === undefined) throw new Error(`Market ${coin} tidak ada. Aktif: ${[...this.markets.keys()].join(", ")}`);
    const lev = Math.floor(Number(leverage));
    if (lev < 1 || lev > MAX_LEVERAGE) throw new Error(`Leverage ${lev}x di atas batas bot (max ${MAX_LEVERAGE}x)`);
    if (Number(margin) < MIN_MARGIN) throw new Error(`Margin minimal $${MIN_MARGIN}`);
    const marginRaw = ethers.parseUnits(Number(margin).toFixed(USDC_DEC), USDC_DEC);
    const intent = {
      user: this.user.address,
      instrumentId,
      isLong: !!isLong,
      fromQueued: false,
      leverage: BigInt(lev),
      margin: marginRaw,
      limitPrice: 0n,
      deadline: deadline(),
      nonce: randNonce(),
    };
    const signature = await this.session.signTypedData(OPEN_DOMAIN, OPEN_TYPES, intent);
    return api("/open", {
      intent: {
        user: intent.user,
        instrumentId: instrumentId.toString(),
        isLong: intent.isLong,
        fromQueued: false,
        leverage: intent.leverage.toString(),
        margin: marginRaw.toString(),
        limitPrice: "0",
        deadline: intent.deadline.toString(),
        nonce: intent.nonce.toString(),
      },
      signature,
    });
  }

  async closePosition(positionId) {
    if (!this.session) throw new Error("Session key belum siap — jalankan `node cli.js setup` dulu");
    const intent = {
      user: this.user.address,
      positionId: BigInt(positionId),
      deadline: deadline(),
      nonce: randNonce(),
    };
    const signature = await this.session.signTypedData(OPEN_DOMAIN, CLOSE_TYPES, intent);
    return api("/close", {
      intent: {
        user: intent.user,
        positionId: intent.positionId.toString(),
        deadline: intent.deadline.toString(),
        nonce: intent.nonce.toString(),
      },
      signature,
    });
  }

  async closeAll() {
    const acct = await this.account();
    const ids = (acct.positions ?? []).map((p) => p.id);
    for (const id of ids) {
      try { await this.closePosition(id); log("Closed position", id); }
      catch (e) { log("Gagal close", id, "-", e.message); }
    }
    return ids.length;
  }

  // ---- perhitungan ----------------------------------------------------------
  // distance to liquidation = 1/leverage - 0.048%  (dari docs resmi)
  liqPrice(entry, isLong, leverage) {
    const d = 1 / leverage - LIQ_BUFFER;
    return isLong ? entry * (1 - d) : entry * (1 + d);
  }

  // ---- mode otomatis --------------------------------------------------------
  // config: { intervalSec, rules: [ { coin, isLong, margin, leverage, tpPct, slPct } ] }
  // - Setiap rule = 1 posisi yang selalu dibuka ulang setelah close (multi market).
  // - tpPct/slPct = % pergerakan harga dari entry ke arah / melawan posisi.
  async runStrategy(config) {
    await this.ensureSessionKey();
    const interval = (config.intervalSec ?? 10) * 1000;
    // mode "semua market": bikin rule otomatis utk setiap market yang ada di relayer,
    // bergantian long/short. Kalau relayer tambah market baru, otomatis ikut.
    if (config.allMarkets) {
      await this.health();
      const coins = [...this.markets.keys()];
      config.rules = coins.map((coin, i) => ({
        coin,
        isLong: config.longFirst ? i % 2 === 0 : i % 2 === 1,
        margin: config.margin ?? 2,
        leverage: Math.min(config.leverage ?? 50, MAX_LEVERAGE),
        tpPct: config.tpPct ?? 0.5,
        slPct: config.slPct ?? 0.3,
      }));
    }
    const openIds = new Map();  // ruleIndex -> { id, openedAt, holdFor }
    const cooldown = new Map(); // ruleIndex -> timestamp boleh buka lagi
    const rnd = (a, b) => a + Math.random() * (b - a);
    const holdMin = config.holdMinSec ?? 40, holdMax = config.holdMaxSec ?? 100;
    const waitMin = config.waitMinSec ?? 30, waitMax = config.waitMaxSec ?? 50;
    log(`Strategy engine ON — ${config.rules.length} rule, interval ${interval / 1000}s, max leverage ${MAX_LEVERAGE}x`);
    log(`Hold per posisi: ${holdMin}-${holdMax}s (acak), jeda antar buka: ${waitMin}-${waitMax}s (acak), TP ${config.tpPct ?? "-"}% SL ${config.slPct ?? "-"}%`);

    const tpSlFor = (coin, kind) => {
      const vals = [];
      for (const r of config.rules ?? []) if (r.coin && r.coin.toUpperCase() === coin && r[kind] != null) vals.push(Number(r[kind]));
      if (config[kind] != null) vals.push(Number(config[kind]));
      return vals.length ? vals[0] : null;
    };

    for (;;) {
      let h, acct;
      try { h = await this.health(); } catch (e) { log("health gagal:", e.message); await sleep(interval); continue; }
      try { acct = await this.account(); } catch (e) { log("account gagal:", e.message); await sleep(interval); continue; }
      const live = new Map((acct.positions ?? []).map((p) => [String(p.id), p]));

      // monitor posisi: TP/SL (safety net) + hold timer (40-100s acak)
      const now = Date.now();
      for (const p of acct.positions ?? []) {
        const coin = this.coins.get(BigInt(p.instrumentId)) || p.market || "?";
        const entry = Number(p.entryPrice ?? p.entry ?? 0) / 1e8;
        const meta = [...openIds.entries()].find(([, m]) => String(m.id) === String(p.id));
        const heldFor = meta ? (now - meta[1].openedAt) / 1000 : null;
        const holdDue = meta && now >= meta[1].openedAt + meta[1].holdFor;
        let tag = null;
        if (entry) {
          const mid = this.midPrice(h, coin);
          if (mid != null) {
            const movePct = ((mid - entry) / entry) * 100 * (p.isLong ? 1 : -1);
            const tp = tpSlFor(coin, "tpPct"), sl = tpSlFor(coin, "slPct");
            if (tp != null && movePct >= tp) tag = `TP (${movePct.toFixed(3)}%)`;
            else if (sl != null && movePct <= -sl) tag = `SL (${movePct.toFixed(3)}%)`;
          }
        }
        if (!tag && holdDue) tag = `hold ${(heldFor ?? 0).toFixed(0)}s habis`;
        if (tag) {
          log(`${coin} id ${p.id} ${p.isLong ? "LONG" : "SHORT"} -> close: ${tag}`);
          try {
            await this.closePosition(p.id);
            if (meta) { openIds.delete(meta[0]); cooldown.set(meta[0], now + rnd(waitMin, waitMax) * 1000); }
          } catch (e) { log("Close gagal", p.id, "-", e.message); }
        }
      }

      // buka posisi per rule — hanya kalau tidak hold, tidak liquidasi, dan cooldown selesai
      for (let i = 0; i < config.rules.length; i++) {
        const rule = config.rules[i];
        const coin = String(rule.coin).toUpperCase();
        const cur = openIds.get(i);
        if (cur != null && live.has(String(cur.id))) continue;
        if (cur != null) {
          const hist = (acct.history ?? []).find((x) => String(x.id) === String(cur.id));
          if (hist) log(`Rule ${i} (${coin}) selesai: kind=${hist.kind ?? "closed"} pnl=$${fmtUsdc(hist.pnl ?? hist.realized ?? 0)}`);
          openIds.delete(i);
        }
        const cd = cooldown.get(i);
        if (cd && now < cd) continue; // masih nunggu jeda 30-50s
        if (cd) cooldown.delete(i);
        try {
          const r = await this.open(coin, rule.isLong, rule.margin, rule.leverage ?? 10);
          if (r && r.positionId != null) {
            openIds.set(i, { id: r.positionId, openedAt: Date.now(), holdFor: rnd(holdMin, holdMax) * 1000 });
            log(`Rule ${i}: OPEN ${coin} ${rule.isLong ? "LONG" : "SHORT"} $${rule.margin} @ ${rule.leverage}x (hold ~${(openIds.get(i).holdFor / 1000).toFixed(0)}s)`);
          }
        } catch (e) {
          log(`Rule ${i}: open gagal —`, e.message);
        }
      }

      await sleep(interval);
    }
  }
}

module.exports = { ZayroBot, api, log, fmtUsdc, CHAIN_ID, API, EXCHANGE, SESSION_KEYS, USDC, LIQ_BUFFER, MAX_LEVERAGE };
