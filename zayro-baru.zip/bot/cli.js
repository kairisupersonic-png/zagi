#!/usr/bin/env node
// zayro bot CLI — long/short semua market, multi position, 1 akun
require("dotenv").config();
const { ZayroBot, api, log, fmtUsdc } = require("./zayro");

const PK = process.env.PRIVATE_KEY;
if (!PK) {
  console.error("Isi PRIVATE_KEY di .env dulu (wallet zayro kamu, bukan seed phrase).");
  process.exit(1);
}
const bot = new ZayroBot(PK, process.env.SESSION_KEY_PRIVATE_KEY || null);
const cmd = process.argv[2];

async function main() {
  if (cmd === "setup") {
    const s = await bot.ensureSessionKey();
    console.log("Session key siap:", s.address);
    const acct = await bot.account();
    console.log("Balance:", fmtUsdc(acct.balance), "USDC | Wallet USDC:", fmtUsdc(acct.walletUsdc ?? 0));
    return;
  }
  if (cmd === "markets") {
    const h = await bot.health();
    for (const [coin, id] of bot.markets) {
      const mid = bot.midPrice(h, coin);
      console.log(`${coin}-PERP  id=${id}  mid=${mid ?? "-"}  maxLev=${bot.maxLev.get(coin)}x`);
    }
    console.log("House bankroll:", h.house ?? "-", "| relayer ok:", h.ok);
    return;
  }
  if (cmd === "account") {
    const h = await bot.health();
    const acct = await bot.account();
    const { ethers } = require("ethers");
    const ex = new ethers.Contract("0xdc803967753cC6A01F9B2bcFc116047189C4a020",
      ["function balances(address) view returns (uint256)", "function queuedOf(address) view returns (uint256)"], bot.provider);
    const [bal, queued] = await Promise.all([ex.balances(bot.user.address), ex.queuedOf(bot.user.address)]);
    console.log("Address :", bot.user.address);
    console.log("Balance :", fmtUsdc(bal), "USDC (di exchange)");
    console.log("Queued  :", fmtUsdc(queued), "USDC (payout queue)");
    console.log("Positions:", (acct.positions ?? []).length);
    for (const p of acct.positions ?? []) {
      const coin = bot.coins.get(BigInt(p.instrumentId)) || p.market || "?";
      const mid = bot.midPrice(h, coin);
      const entry = Number(p.entryPrice ?? p.entry ?? 0) / 1e8;
      const move = entry ? (((mid - entry) / entry) * 100 * (p.isLong ? 1 : -1)).toFixed(3) : "?";
      console.log(`  id=${p.id} ${coin} ${p.isLong ? "LONG" : "SHORT"} margin=$${fmtUsdc(p.margin)} lev=${p.leverage}x entry=${entry} move=${move}% liq≈${entry ? bot.liqPrice(entry, p.isLong, Number(p.leverage)).toPrecision(8) : "?"}`);
    }
    return;
  }
  if (cmd === "open") {
    // node cli.js open BTC long 5 50   (market, side, margin USDC, leverage)
    const [coin, side, margin, lev] = process.argv.slice(3);
    if (!coin || !side || !margin) {
      console.log("Pemakaian: node cli.js open <MARKET> <long|short> <marginUSDC> <leverage>");
      return;
    }
    await bot.ensureSessionKey();
    const r = await bot.open(coin, String(side).toLowerCase() === "long", Number(margin), Number(lev || 10));
    console.log("OK:", JSON.stringify(r));
    return;
  }
  if (cmd === "close") {
    const id = process.argv[3];
    if (!id) { console.log("Pemakaian: node cli.js close <positionId>  |  close all"); return; }
    await bot.ensureSessionKey();
    if (id === "all") { const n = await bot.closeAll(); console.log("Closed", n, "posisi"); }
    else { const r = await bot.closePosition(id); console.log("OK:", JSON.stringify(r)); }
    return;
  }
  if (cmd === "history") {
    const acct = await bot.account();
    for (const hh of (acct.history ?? []).slice(-20).reverse()) {
      console.log(`id=${hh.id} ${hh.market ?? hh.coin ?? "?"} ${hh.isLong ? "LONG" : "SHORT"} ${hh.kind} pnl=$${fmtUsdc(hh.pnl ?? 0)} zayro=${hh.minted ?? 0}`);
    }
    return;
  }
  if (cmd === "multi") {
    require("./multi");
    return;
  }
  if (cmd === "run") {
    // node cli.js run [strategy.json]
    const file = process.argv[3] || "strategy.json";
    const config = JSON.parse(require("fs").readFileSync(require("path").join(__dirname, file), "utf8"));
    await bot.runStrategy(config);
    return;
  }
  console.log(`zayro bot — GIWA Sepolia testnet
Perintah:
  node cli.js setup                          daftarkan session key (sekali)
  node cli.js markets                        lihat market + harga
  node cli.js account                        balance + posisi open
  node cli.js open BTC long 5 50             open: market side margin leverage
  node cli.js close <id> | all               tutup posisi
  node cli.js history                        riwayat trade
  node cli.js run [strategy.json]            mode otomatis 1 akun (hold timer + TP/SL)
  node cli.js multi                          MULTI AKUN paralel (baca ACCOUNTS di .env)`);
}

main().catch((e) => { console.error("ERROR:", e.message); process.exit(1); });
