# zayro-bot (Node.js)

Bot trading untuk **zayro.trade** — perpetual futures di GIWA Sepolia testnet.
Satu akun, bisa multi posisi, semua market (BTC / ETH / SOL / XRP), long atau short bebas.

Semua cara kerja bot ini sama persis dengan yang dilakukan website-nya: bot sign
EIP-712 intent (OpenIntent / CloseIntent / RegisterSessionKey) dan kirim ke relayer
`https://zayro.trade/api-giwa`. Relayer yang bayar gas. Tidak ada order book, isi di mid price.

## Setup

```bash
npm install
cp .env.example .env    # isi PRIVATE_KEY (wallet zayro kamu, testnet!)
node cli.js setup       # daftarkan session key (sekali, tanda tangan 1x, tanpa gas)
```

`setup` otomatis bikin session key burner dan simpan ke `session-key.json`.
Session key hanya bisa open/close posisi — tidak bisa withdraw.

## Perintah

```bash
node cli.js markets                  # semua market + harga mid live
node cli.js account                  # balance, posisi open, estimasi liq price
node cli.js open BTC long 5 50       # open BTC long margin $5 leverage 50x
node cli.js open ETH short 2 100
node cli.js close <positionId>       # tutup 1 posisi
node cli.js close all                # tutup semua
node cli.js history                  # riwayat trade (pnl, ZAYRO yang di-mint)
node cli.js run                      # mode otomatis dari strategy.json
```

Leverage **max 50× (dibatasi bot)** — ubah lewat env `MAX_LEVERAGE` kalau mau. Margin min $1. Min deposit/withdraw 10 USDC.

Market: bot otomatis pakai **semua market yang terdaftar di relayer** (saat ini BTC/ETH/SOL/XRP). Tidak ada koin yang di-hardcode — kalau zayro menambah market baru, bot langsung trade market itu juga.

## Multi akun

Isi `.env`:
```env
ACCOUNTS=["0x_pvkey_akun1","0x_pvkey_akun2","0x_pvkey_akun3"]
```
atau `PRIVATE_KEY=...`, `PRIVATE_KEY2=...`, dst. Lalu:
```bash
node cli.js multi
```
Semua akun jalan paralel — masing-masing setup session key sendiri (file `session-key-<address>.json`),
semua trade semua market, hold 40–100s, jeda 30–50s. Satu akun error tidak menghentikan yang lain.

## Mode otomatis (`strategy.json`)

**Mode semua market (default):**

```json
{
  "allMarkets": true,
  "longFirst": true,
  "margin": 2,
  "leverage": 50,
  "tpPct": 0.5,
  "slPct": 0.3,
  "intervalSec": 10
}
```

- `allMarkets: true` → rule dibuat otomatis untuk **semua market di relayer**, sisi long/short bergantian, leverage max 50×. Market baru dari zayro otomatis ikut.
- `longFirst: true` → market pertama long, kedua short, dst.

**Mode manual per rule (kalau mau atur sendiri):**

```json
{
  "intervalSec": 10,
  "rules": [
    { "coin": "BTC", "isLong": true,  "margin": 2, "leverage": 50, "tpPct": 0.5, "slPct": 0.3 },
    { "coin": "ETH", "isLong": false, "margin": 2, "leverage": 50, "tpPct": 0.5, "slPct": 0.3 }
  ]
}
```

- **Hold timer**: tiap posisi ditahan acak `holdMinSec`–`holdMaxSec` detik (default 40–100s),
  lalu close otomatis, tunggu acak `waitMinSec`–`waitMaxSec` detik (default 30–50s), lalu buka lagi. Ngulang terus.
- `tpPct` / `slPct` = safety net berbasis % pergerakan harga dari entry — kena duluan mana yang lebih dulu.
  Set besar (mis. tp 5 / sl 1.5) kalau mau hold timer yang jadi exit utama.
- Setiap rule/market = 1 posisi bersamaan. Tambah/rubah rule sesukamu.
- Kosongkan tpPct/slPct di rule → pakai nilai global di atas.

## Catatan penting

- **Testnet only** — GIWA Sepolia, dana test, tidak ada nilai nyata. Kontrak belum diaudit.
- Likuidasi: `1 / leverage − 0.048%` melawan posisi. Di 1000×, gerak 0.05% langsung cair.
- Fee hanya saat close profit (haircut + 2%). Loss tidak kena fee tambahan.
- Pergerakan dicatat sebagai points: 1 point per $1 realised result (max 50.000/hari UTC).
- Kalau relayer mati, open/close berhenti sampai dia online lagi.
