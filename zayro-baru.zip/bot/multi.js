#!/usr/bin/env node
// multi akun — semua akun jalan paralel, masing-masing strategy sendiri
// (setup session key otomatis per akun saat pertama kali)
const fs = require("fs");
const path = require("path");
const { ZayroBot, log } = require("./zayro");

// parse .env sendiri (tanpa dotenv) — support ACCOUNTS JSON & PRIVATE_KEY, PRIVATE_KEY2..N
function loadEnv() {
  const file = path.join(__dirname, ".env");
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
loadEnv();

function collectPrivateKeys() {
  const keys = [];
  if (process.env.ACCOUNTS) {
    const arr = JSON.parse(process.env.ACCOUNTS);
    for (const a of arr) {
      const pk = typeof a === "string" ? a : a.privateKey;
      if (pk) keys.push(pk);
    }
  } else {
    for (const [k, v] of Object.entries(process.env)) {
      if (/^PRIVATE_KEY(\d+)?$/.test(k) && v && v.startsWith("0x")) keys.push(v);
    }
  }
  return keys;
}

async function main() {
  const keys = collectPrivateKeys();
  if (!keys.length) {
    console.error("Tidak ada private key. Isi di .env salah satu:\n" +
      "  ACCOUNTS=[\"0xabc...\",\"0xdef...\"]\n" +
      "  atau: PRIVATE_KEY=0x..., PRIVATE_KEY2=0x..., PRIVATE_KEY3=0x...\n" +
      "atau tetap pakai PRIVATE_KEY tunggal untuk 1 akun.");
    process.exit(1);
  }
  log(`Multi akun: ${keys.length} akun paralel`);

  const strategy = JSON.parse(fs.readFileSync(path.join(__dirname, process.argv[2] || "strategy.json"), "utf8"));

  await Promise.all(keys.map(async (pk, i) => {
    const bot = new ZayroBot(pk);
    const tag = `akun${i + 1}`;
    try {
      await bot.ensureSessionKey();
      const acct = await bot.account();
      log(`[${tag}] ${bot.user.address} siap — ${(acct.positions ?? []).length} posisi open`);
    } catch (e) {
      log(`[${tag}] setup gagal:`, e.message, "— akun ini dilewati");
      return;
    }
    // jalankan loop strategy per akun (never crash the others)
    for (;;) {
      try {
        await bot.runStrategy(strategy);
      } catch (e) {
        log(`[${tag}] strategy error:`, e.message, "— restart 10s");
        await new Promise((r) => setTimeout(r, 10000));
      }
    }
  }));
}

main().catch((e) => { console.error("FATAL:", e.message); process.exit(1); });
